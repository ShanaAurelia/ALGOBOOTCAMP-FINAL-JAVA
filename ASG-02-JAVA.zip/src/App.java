import java.util.concurrent.ThreadLocalRandom;

public class App {

    private String ID;
	private String name;
	private String category;
	private String releaseDate;
	private Integer price;

    public App(String name, String category, String releaseDate, Integer price) {
        this.ID = makeID();
        this.name = name;
        this.category = category;
        this.releaseDate = releaseDate;
        this.price = price;
    }

    public String makeID(){
        String ID = "SH";
        for(int i = 0; i < 3; i++){
            Integer randomNumber = ThreadLocalRandom.current().nextInt(0, 10);
            ID = ID + randomNumber.toString(); 
        }
        return ID;
    }

    public String toString() {
        String result = "";
        result = result + this.name + "" + this.ID + "\n";
        result = result + "Category: " + this.category + "\n";
		result = result + "Release date: " + this.releaseDate + "\n";
		result = result + "Price: " + this.price + "\n";
        return result;
    }

    public String gotID(){
        return ID;
    }

    public void settingID(String iD) {
		ID = iD;
	}

	public String gotName() {
		return name;
	}

	public void settingName(String name) {
		this.name = name;
	}

	public String gotCategory() {
		return category;
	}

	public void settingCategory(String category) {
		this.category = category;
	}

	public String gotReleaseDate() {
		return releaseDate;
	}

	public void settingReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public Integer gotPrice() {
		return price;
	}

	public void settingPrice(Integer price) {
		this.price = price;
	}
    
}
