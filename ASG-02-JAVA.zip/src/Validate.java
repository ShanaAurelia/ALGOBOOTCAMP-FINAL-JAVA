import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Validate {

    boolean name(String Shoename){
        return Shoename.endsWith("shoe") ? true : false;	
    }

    boolean category(String ShoeCategory) {
		return (ShoeCategory.contentEquals("Sneaker") || ShoeCategory.contentEquals("Running") || ShoeCategory.contentEquals("Boot")) ? true : false;
	}
	
	boolean releaseDate(String Shoedate) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd-mm-yyyy");
			sdf.setLenient(false);
			sdf.parse(Shoedate);
		} catch(ParseException pe) {
			return false;
		}
		return true;
	}
	
	boolean price(Integer shoePrice) {
		return (shoePrice >= 5000) ? true : false;
	}
	
	public static void main() {
		new Validate();
	}
}
