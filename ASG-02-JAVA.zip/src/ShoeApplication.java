import java.util.ArrayList;
import java.util.Scanner;

public class ShoeApplication {
    Scanner scan = new Scanner(System.in);
    ArrayList<App> shoeStruct = new ArrayList<>();
    Validate check = new Validate();

    public void view(){
        if (shoeStruct.isEmpty()) {
			System.out.println("No shoes avalaible..");
			System.out.println("Press enter to continue ..");
			return;
		}
		
		for (int i = 1; i <= shoeStruct.size(); i++) {
			System.out.println(i + ". " + shoeStruct.get(i-1).toString());
		}
    }

    public void add(){
        String tempName = null;
        do{
            System.out.print("Input shoe's name[name ends with shoe, example: \"Fire shoe\"]: ");
			tempName = scan.nextLine();
        }while(!check.name(tempName));

        String tempCategory = null;
        do{
            System.out.print("Input shoe's category[Sneaker | Running | Boot] (case sensitive): ");
			tempCategory = scan.nextLine();
        }while(!check.category(tempCategory));

        String tempDate = null;
        do{
            System.out.print("Input shoe's release date[dd-mm-yyyy]: ");
			tempDate = scan.nextLine();
        }while(!check.releaseDate(tempDate));

        Integer tempPrice = -1;
        do {
			System.out.print("Input shoe's price[more than or equals to 5000]: ");
			tempPrice = scan.nextInt(); 
            scan.nextLine();
		} while (!check.price(tempPrice));

        System.out.println("Shoe added!");
		System.out.println("Press enter to continue...");
		scan.nextLine();
		App newShoe = new App(tempName, tempCategory, tempDate, tempPrice);
		shoeStruct.add(newShoe);
    }

    public void delete(){
        int size = shoeStruct.size();
		boolean isValidIndex;
		int index;
		
		do {
			isValidIndex = true;
			System.out.printf("Choose shoe's number to delete[1..%d]: ", size);
			index = scan.nextInt(); scan.nextLine();
			if(index < 1 || index > size) isValidIndex = false;
		} while (!isValidIndex);
		
		shoeStruct.remove(index-1);
		System.out.println("Shoe removed!");
    }

    public ShoeApplication(boolean online){
        do{
            for (int i = 0; i < 50; i++) {
				System.out.println();
			}
			System.out.println("Shoe Shop");
			System.out.println("1. View Shoes");
			System.out.println("2. Add Shoe");
			System.out.println("3. Delete Shoe");
			System.out.println("4. Exit");
			
			int choice;
			boolean isValidChoice = true;
			
			do {
				System.out.print(">> ");
				choice = scan.nextInt(); scan.nextLine();
				if (choice < 1 || choice > 4) {
					isValidChoice = false;
				}
			} while (!isValidChoice);
			
			switch (choice) {
			case 1:
				view();
				scan.nextLine();
				break;
			case 2:
				add();
				break;
			case 3:
				view();
				if (!shoeStruct.isEmpty()) {
					delete();
				}
				scan.nextLine();
				break;
			case 4:
				System.out.println("Thank you!");
				online = false;
				break;
			}
        }while(online);
    }

    public static void main(String[] args) {
		new ShoeApplication(true);
	}
}
