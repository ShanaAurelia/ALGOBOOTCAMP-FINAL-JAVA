import java.util.*;

public class App {

    public static Scanner scan = new Scanner(System.in);

    public static void printTable(int a, int b, String sum, char a_char, char b_char, int a_x_b, float a_per_b, boolean bool){
        System.out.println("+=========================================================================================================================+");
		System.out.println("+  + (String type)  |  (Character Type)  |  * (Integer Type)  |  / (Floating Type)  |  input 1 == input 2 (Boolean Type)  +");
		System.out.println("+=========================================================================================================================+");
		System.out.printf("| %-18s| %8c  %-9c| %-19s| %-20.3f| %-36s|\n", sum, a_char, b_char, a_x_b, a_per_b, bool);
		System.out.println("+=========================================================================================================================+");
		
		System.out.println("+===========================================================+");
		System.out.println("+Data Type : Integer                                        +");
		System.out.println("+===========================================================+");
		System.out.println("+     +     |     -     |     *     |     /     |     %     +");
		System.out.println("+===========================================================+");
		System.out.printf("+ %-10d| %-10d| %-10d| %-10d| %-10d+\n", (a + b), (a - b), (a * b), (a / b), (a % b));
		System.out.println("+===========================================================+");
		scan.nextLine();
    }

    public static void printLogic(boolean val1, boolean val2, char logic_1, char logic_2){
        System.out.println("+=====================================================================+");
		System.out.println("+Logical Table                                                        +");
		System.out.println("+=====================================================================+");
		System.out.printf("+ P1 = %c , P2 = %c                                                     +\n", logic_1, logic_2);
		System.out.println("+=====================================================================+");
		System.out.println("+       !P1       |       !P2       |       &&       |       ||       +");
		System.out.println("+=====================================================================+");
		System.out.printf("+ %-16s| %-16s| %-15s| %-15s|\n", (!val1), (!val2), (val1 && val2), (val1 || val2));
		System.out.println("+=====================================================================+");
		scan.nextLine();
		scan.nextLine();
    }

    public static void simulate(){
        int a, b;
        do {
			System.out.print("Input the first number [1-100](inclusive): ");
			a = scan.nextInt(); 
            scan.nextLine();
		} while (a < 1 || a > 100);
		
		do {
			System.out.print("Input the second number [1-100](inclusive): ");
			b = scan.nextInt(); 
            scan.nextLine();
		} while (b < 1 || b > 100);

        String sum_string = Integer.toString(a) + " + " + Integer.toString(b);
		char a_char = (char) a;
		char b_char = (char) b;
		int a_x_b = a*b;
		float a_per_b = (float) a/b;
		boolean bool = false;
		if (a == b) {
            bool = true;
        }
        printTable(a, b, sum_string, a_char, b_char,a_x_b, a_per_b, bool);  
        for (int i = 0; i < 50; i++) {
			System.out.println();
		}

        boolean val1, val2;
        do {
			System.out.print("Give me value for p1 [true | false]: ");
			val1 = scan.nextBoolean();
		} while (val1 != false && val1 != true);
        do{
            System.out.print("Give me value for p2 [true | false]: ");
			val2 = scan.nextBoolean(); 
        }while (val2 != false && val2 != true);

        char logic_1;
        if(val1 == true){
            logic_1 = 'T';
        }else{
            logic_1 = 'F';
        }

        char logic_2;
        if(val1 == true){
            logic_2 = 'T';
        }else{
            logic_2 = 'F';
        }

        printLogic(val1, val2, logic_1, logic_2);
        for (int i = 0; i < 50; i++) {
			System.out.println();
		}
    }

    public App(boolean online){
        System.out.println("BJ-JPTable");
        int choice;
		while(online) {
			System.out.println("1. Start The Simulation!!");
			System.out.println("2. Close App");
			System.out.print("Choice 	>> ");
			choice = scan.nextInt(); scan.nextLine();
			switch(choice){
               case 1 : 
                    simulate();
                    break;
                case 2: 
                    online = false;
                    break;
            }
		System.out.println("thank you for using the apps");
    }
    }

    public static void main(String[] args) throws Exception {
        new App(true);
    }
}
